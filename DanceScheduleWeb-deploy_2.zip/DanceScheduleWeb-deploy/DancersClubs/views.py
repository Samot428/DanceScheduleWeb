from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from TrainerClubs.models import Club
from main.models import Day, Couple, Trainer, Dancer, Group
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.contrib import messages
from datetime import time, datetime, date, timedelta
from sheet.models import SheetCell
# Create your views here.
@login_required
def dancers_dashboard(request):
    """Shows the trainer clubs"""
    
    clubs = Club.objects.all()
    dancer = get_object_or_404(Dancer, uid=request.user.id)
    if dancer.in_couple:
        if dancer.sex == "male":
            couple = get_object_or_404(Couple, man=dancer)
        else:
            couple = get_object_or_404(Couple, woman=dancer)
    else:
        couple = None
    return render(request, 'dancers_clubs_view.html', {'clubs':clubs, 'dancer':dancer, 'couple':couple})

@login_required
def show_club(request, club_id):
    """View of the seperate clubs"""
    club = get_object_or_404(Club, id=club_id)
    days = Day.objects.filter(club=club).all()
    paginator = Paginator(days, 2)
    page_number = request.GET.get('page',1)
    page_obj = paginator.get_page(page_number)
    user_dancer = get_object_or_404(Dancer, uid=request.user.id)

    try:
        if user_dancer.sex == "male":
            c = get_object_or_404(Couple, man=user_dancer)
        else:
            c = get_object_or_404(Couple, woman=user_dancer)
    except:
        c = None

    return render(request, 'dancers_clubs_day_view.html', {'club':club, 'days':page_obj.object_list, 'page_obj':page_obj, 'user_dancer': user_dancer, "c":c})

def find_club(request):
    """View of the specific clubs"""
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    club_name = request.POST.get('looking_for_club')
    dancer = get_object_or_404(Dancer, uid=request.user.id)
    if dancer.in_couple:
        if dancer.sex == "male":
            couple = get_object_or_404(Couple, man=dancer)
        else:
            couple = get_object_or_404(Couple, woman=dancer)
    else:
        couple = None
    if club_name.lower() == 'all':
        clubs = Club.objects.all()
        return render(request, 'dancers_clubs_view.html', {'clubs':clubs, 'dancer':dancer, 'couple':couple})
    club = get_object_or_404(Club, name=club_name)
    return render(request, 'dancers_clubs_view.html', {'clubs': [club], 'dancer':dancer, 'couple':couple})

def add_couple(request, club_id):
    """Add a couple to day by a dancer"""
    if request.method != 'POST':
        return JsonResponse({'error':'Method not allowed'}, status=405)
    print("adding")
    day_id = request.POST.get('day_id')
    if day_id:
        confirmed = request.POST.get('confirmed') == 'true'
        club = get_object_or_404(Club, id=club_id)    
        day = get_object_or_404(Day, id=day_id, club=club)
        dancer = get_object_or_404(Dancer, uid=request.user.id)
        if dancer.in_couple:
            if dancer.sex == "male":
                c = get_object_or_404(Couple, man=dancer)
                if c.woman in day.dancers.all():
                    day.dancers.remove(c.woman)
                    day.couples.add(c)
                else:
                    day.dancers.add(dancer)
            else:
                c = get_object_or_404(Couple, woman=dancer)
                if c.man in day.dancers.all():
                    day.dancers.remove(c.man)
                    day.couples.add(c)
                else:
                    day.dancers.add(dancer)
            day.save()
        elif dancer not in day.dancers.all():
            day.dancers.add(dancer)
            day.save()
        
        club = get_object_or_404(Club, id=club_id)
        groupOthers, nu= Group.objects.get_or_create(name="Others", index=0, club=club, user=club.club_owner)
        if not nu:
            if dancer.in_couple:
                if dancer.sex == "male":
                    c = get_object_or_404(Couple, man=dancer)
                    if c.woman in groupOthers.dancers.all():
                        groupOthers.couples.add(c)
                elif dancer.sex == "female":
                    c = get_object_or_404(Couple, woman=dancer)
                    if c.man in groupOthers.dancers.all():
                        groupOthers.couples.add(c)
            groupOthers.dancers.add(dancer)
            groupOthers.save()
            return redirect(f'/dancer/club/{club_id}') 

        if groupOthers:
            if dancer.in_couple:
                if dancer.sex == "male":
                    c = get_object_or_404(Couple, man=dancer)
                    if c.woman in groupOthers.dancers.all():
                        groupOthers.couples.add(c)
                elif dancer.sex == "female":
                    c = get_object_or_404(Couple, woman=dancer)
                    if c.man in groupOthers.dancers.all():
                        groupOthers.couples.add(c)
            groupOthers.dancers.add(dancer)
            groupOthers.save()
            # Initialize SheetCells for the new group
            days = Day.objects.filter(club=club).all()
            
            # Calculate number of rows based on days and time slots
            def col_name(index):
                name = ""
                while index >= 0:
                    name = chr(index % 26 + 65) + name
                    index = index // 26 - 1
                return name
            
            def day_and_time_slots(days, interval_minutes=30):
                """Returns time slots for each day in given interval"""
                slots = []
                dslots = []
                slots.append("")
                dslots.append("")
                for day in days:
                    start_dt = datetime.combine(date.today(), day.start_time)
                    end_dt = datetime.combine(date.today(), day.end_time)
                    while start_dt <= end_dt:
                        if day.name not in dslots:
                            dslots.append(day.name)
                        else:
                            dslots.append("")
                        slots.append(start_dt.strftime("%H:%M"))
                        start_dt += timedelta(minutes=interval_minutes)
                    dslots.append("")
                    slots.append("")  # separator between days
                return slots, dslots
            
            tslots, dslots = day_and_time_slots(days=days)
            NUM_ROWS = len(tslots)
            NUM_COLS = 26
            
            # Create empty SheetCells for this group
            sheet_cells_to_create = []
            for row in range(NUM_ROWS):
                for col_idx in range(NUM_COLS):
                    col = col_name(col_idx)
                    sheet_cells_to_create.append(
                        SheetCell(club=club, group=groupOthers, row=row, col=col, value="", color="")
                    )
            
            # Bulk create the cells
            SheetCell.objects.bulk_create(sheet_cells_to_create, ignore_conflicts=True)
        
    return redirect(f'/dancer/club/{club_id}')

def delete_couple(request, club_id, couple_id):
    """Delete a couple from day by a dancer"""
    if request.method != 'POST':
        return JsonResponse({'error':'Method not allowed'}, status=405)

    club = get_object_or_404(Club, id=club_id)
    day_id = request.POST.get('day_id')
    day = get_object_or_404(Day, id=day_id, club=club)

    dancer = Dancer.objects.get(uid=couple_id)
    if dancer.in_couple:
        if dancer.sex == "male":
            couple = get_object_or_404(Couple, man=dancer)
        else:
            couple = get_object_or_404(Couple, woman=dancer)
        if couple in day.couples.all():
            day.couples.remove(couple)
        else:
            day.dancers.remove(dancer)
    else:
        day.dancers.remove(dancer)
        
    day.save()

    return redirect(f"/dancer/club/{club_id}")

def create_couple_view(request):
    """User can create a couple with another user (only one couple per user)"""
    
    clubs = Club.objects.all()
    groups = Group.objects.all()

    dancer1 = get_object_or_404(Dancer, uid=request.user.id)

    sex = dancer1.sex
    if sex == "male":
        dancers = Dancer.objects.filter(in_couple=False, sex="female")
    else:
        dancers = Dancer.objects.filter(in_couple=False, sex="male")

    return render(request, "dancers_create_couple_view.html", {'dancer1':dancer1, 'clubs':clubs, 'dancers':dancers, 'groups':groups})

def create_couple_by_user(request):
    if request.method != 'POST':
        return JsonResponse({'error':'Method not allowed'}, status=405)

    dancer1_id = request.POST.get('dancer1')
    dancer2_id = request.POST.get('dancer2')
    couple_class_stt = request.POST.get('classSTT')
    couple_class_lat = request.POST.get('classLAT')
    club_id = request.POST.get('club')
    group_id = request.POST.get('group')
    

    dancer1 = get_object_or_404(Dancer, id=dancer1_id)
    dancer2 = get_object_or_404(Dancer, id=dancer2_id)

    club = get_object_or_404(Club, id=club_id)
    group = get_object_or_404(Group, id=group_id)
    
    if dancer1.in_couple or dancer2.in_couple:
        return redirect("/dancer/dancer_dashboard/")
    if dancer1.sex == "male":
        man=dancer1
        woman=dancer2
    else:
        man=dancer2
        woman=dancer1

    print(couple_class_lat)
    Couple.objects.create(
        name=f"{dancer1.name} & {dancer2.name}",
        dance_class_stt=couple_class_stt.upper(),
        dance_class_lat=couple_class_lat.upper(),
        man=man,
        woman=woman,
        group=group,
        )

    dancer1.in_couple = True 
    dancer2.in_couple = True
    
    dancer1.save()
    dancer2.save()

    return redirect('/dancer/dancers_dashboard/')