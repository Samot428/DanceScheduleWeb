
from django.db import models
import json
from datetime import time
from TrainerClubs.models import Club
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AbstractUser

class UserProfile(models.Model):
    USER_SEX_CHOICES = [
        ("female", "Female"),
        ("male", "Male"),
    ]

    USER_TYPE_CHOICES = [
        ('dancer', 'Dancer'),
        ('trainer', 'Trainer'),
    ]
    TRAINER_FOCUS_CHOICES = [
        ('stt', 'STT'),
        ('lat', 'LAT'),
        ('s&l', 'S&L'),
    ]

    DANCER_CLASS = [
        ('e', 'E'),
        ('d', 'D'),
        ('c', 'C'),
        ('b', 'B'),
        ('a', 'A'),
        ('s', 'S'),
        ('pro', 'PRO'),
    ]
    user = models.OneToOneField(get_user_model(), on_delete=models.CASCADE)
    user_type = models.CharField(
        max_length=10,
        choices=USER_TYPE_CHOICES,
        default='dancer',
    )

    trainer_focus = models.CharField(
        max_length=10,
        choices=TRAINER_FOCUS_CHOICES,
        default='s&l'
    )

    DancerClassSTT = models.CharField(
        max_length=100,
        choices=DANCER_CLASS,
        default='c'
    )

    DancerClassLat = models.CharField(
        max_length=100,
        choices=DANCER_CLASS,
        default='c'
    )

    user_sex = models.CharField(max_length=10, null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.user_type}"
User = get_user_model()

# Create your models here.
class Dancer(models.Model):
    name = models.CharField(max_length=200)
    min_duration = models.IntegerField(default=60)

    dance_class_stt = models.CharField(max_length=100, default='B')
    dance_class_lat = models.CharField(max_length=100, default='B')

    in_couple = models.BooleanField(default=False)
    sex = models.CharField(default="male", max_length=10)

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dancer', null=True, blank=True)
    uid = models.IntegerField(default=0)

    group = models.ForeignKey('Group', on_delete=models.SET_NULL, related_name='dancers', null=True, blank=True)
    club = models.ForeignKey(Club, on_delete=models.SET_NULL, related_name='dancers', null=True, blank=True)

    def __str__(self):
        return self.name
    
    def get_time(self):
        """Return time_availability as a dictionary"""
        try:
            return json.loads(self.time_availability) if self.time_availability else {}
        except (json.JSONDecodeError, TypeError):
            return {}

class Couple(models.Model):
    # null and blank are True, because couple can be created also by a dancer not just by a trainer in a club
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='couple', null=True, blank=True)
    uid = models.IntegerField(default=0)

    name = models.CharField(max_length=200)
    min_duration = models.IntegerField(default=60)

    man = models.ForeignKey(Dancer, on_delete=models.CASCADE, related_name="man", null=True, blank=True)
    woman = models.ForeignKey(Dancer, on_delete=models.CASCADE, related_name="woman", null=True, blank=True)
    
    group = models.ForeignKey('Group', on_delete=models.SET_NULL, related_name='couples', null=True, blank=True)
    club = models.ForeignKey(Club , on_delete=models.SET_NULL, related_name="couples", null=True, blank=True)
    
    dance_class_lat = models.CharField(max_length=100,)
    dance_class_stt = models.CharField(max_length=100,)
    def __str__(self):
        return self.name

    def nlt(self):
        return self.name, self.dance_class_stt, self.dance_class_lat

    def dancers_names(self):
        """Parse the couple name to extract individual dancer names"""
        name = str(self.name)
        if " and " in name:
            fd, sd = name.split(" and ")
            fd = fd.rstrip()
            sd = sd.rstrip()
            return fd, sd
        elif " a " in name:
            fd, sd = name.split(" a ")
            fd = fd.rstrip()
            sd = sd.rstrip()
            return fd, sd
        return None, None
    
    def extract_times(self, ft, st):
        """Extract common time windows for both dancers"""
        f_keys = ft.keys() if isinstance(ft, dict) else []
        s_keys = st.keys() if isinstance(st, dict) else []
        times = []
        for t in f_keys:
            if t in s_keys:
                times.append(t)
        return times
    
    def time_avail(self):
        """Calculate availability for the pair based on both dancers"""
        # Get dancer names
        fd_name, sd_name = self.dancers_names()
        if not fd_name or not sd_name:
            return {}
        
        # Find dancer objects
        try:
            fd = Dancer.objects.get(name=fd_name.strip())
            sd = Dancer.objects.get(name=sd_name.strip())
        except Dancer.DoesNotExist:
            return {}
        
        # Get times for both dancers (now returns dict)
        ft = fd.get_time()
        st = sd.get_time()
        
        # Extract common times
        times = self.extract_times(ft, st)
        
        time_availability = {}
        for t in times:
            # Both dancers must be available (check boolean values)
            time_availability[t] = ft.get(t) and st.get(t)
        
        return time_availability
    
    def get_time(self):
        """Get the availability for this couple"""
        return self.time_avail()

class Trainer(models.Model):
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='trainer', null=True, blank=True)
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='trainer', null=True, blank=True)
    uid = models.IntegerField(default=0)
    
    name = models.CharField(max_length = 200)
    sex = models.CharField(max_length=10, null=True, blank=True)

    group_lesson = models.ManyToManyField('GroupLesson', related_name='trainer', blank=True)
    
    start_time = models.TimeField()
    end_time = models.TimeField()
    
    focus = models.CharField(max_length=10, default="S&L")

    def __str__(self):
        return self.name
    def get_availability(self):
        return self.start_time, self.end_time
    def group_lesson_time(self):
        return self.group_lesson

class Day(models.Model):
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name="day", blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='day')
    name = models.CharField(max_length=200)
    couples = models.ManyToManyField('Couple', related_name='days', blank=True)
    dancers = models.ManyToManyField('Dancer', related_name='days', blank=True)
    start_time = models.TimeField(default=time(8,0))
    end_time = models.TimeField(default=time(21,0))
    trainers = models.ManyToManyField('Trainer', related_name='day', blank=True)
    def __str__(self):
        return self.name
    def add_trainer(self, trainer):
        trainer = Trainer.objects.get(name=trainer) 
        self.trainers[trainer.__str__()] = trainer.group_lesson_time()
        return f"{trainer} added"
    def remove_trainer(self, trainer):
        trainer = Trainer.objects.get(name=trainer)
        del self.trainers[trainer.__str__()]
        return f"{trainer} removed"
    
class Group(models.Model):
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='groups', null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='owned_groups')
    name = models.CharField(max_length=200)
    index = models.IntegerField(default=0)  # For sorting groups
    couples = []
    def __str__(self):
        return self.name

    def get_couples(self):
        return self.couples
    def add_couple(self, couple):
        self.couples.append(Couple.objects.get(name=couple))
        return f"{couple} added"
    def remove_couple(self, couple):
        self.couples.remove(Couple.objects.get(name=couple))
        return f"{couple} removed"

class GroupLesson(models.Model):
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='group_lessons', blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='group_lessons')
    day = models.ForeignKey('Day', on_delete=models.CASCADE, related_name='group_lessons', null=True, blank=True)
    groups = models.ManyToManyField('Group', related_name='group_lessons', blank=True)
    time_interval_start = models.TimeField(default=time(0, 0))
    time_interval_end = models.TimeField(default=time(0, 0))

    def __str__(self):
        return f"{self.time_interval_start}-{self.time_interval_end}"

class TrainerDayAvailability(models.Model):
    """Per-day availability for a trainer, avoiding global overwrites."""
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='trainer_availabilities', blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='trainer_availabilities')
    day = models.ForeignKey('Day', on_delete=models.CASCADE, related_name='trainer_availabilities')
    trainer = models.ForeignKey('Trainer', on_delete=models.CASCADE, related_name='day_availabilities')
    start_time = models.TimeField()
    end_time = models.TimeField()

    class Meta:
        unique_together = ('day', 'trainer')

    def __str__(self):
        return f"{self.trainer.name} @ {self.day.name}: {self.start_time}-{self.end_time}"

class DancersAvailability(models.Model):
    club = models.ForeignKey(Club, on_delete=models.CASCADE, related_name='dancer_availabilities', blank=True, null=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='dancer_availabilities')
    dancer = models.ForeignKey('Dancer', on_delete=models.CASCADE, related_name='dancer_availabilities')
    day = models.ForeignKey('Day', on_delete=models.CASCADE, related_name='dancer_availabilities')
    availability = models.JSONField(default=list)  # Stores [True, False, True, ...]
    
    def __str__(self):
        return f"{self.dancer.name} @ {self.day.name}: {self.availability}"
